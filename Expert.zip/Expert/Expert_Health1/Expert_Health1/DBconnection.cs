﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
namespace Expert_Health1
{
    class DBconnection
    {
        public SqlConnection connection;
        public DBconnection()
        {
            connection = new SqlConnection("server = localhost; database = ExpertDaro; integrated security = true");

            
        }
        public DataSet readFromDB(SqlCommand command, string xxx)
        {
            DBconnection d = new DBconnection();
            d.connection.Open();
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = command;
            da.SelectCommand.Connection = d.connection;
            DataSet ds = new DataSet();

            da.Fill(ds, xxx);
           
            d.connection.Close();
            return ds;

        }
    }
}
