﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace Expert_Health1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DBconnection dd = new DBconnection();
            dd.connection.Open();
            if (radioButton1.Checked == true)
            {

                SqlDataAdapter Da = new SqlDataAdapter();
                Da.SelectCommand = new SqlCommand();
                Da.SelectCommand.CommandText = "Insert_bimari_cheshmi";
                SqlParameter code_K = new SqlParameter("@alaem_cheshmi", SqlDbType.NVarChar);
                code_K.Direction = ParameterDirection.Input;
                code_K.Value = textBox1.Text;
                Da.SelectCommand.Parameters.Add(code_K);
                SqlParameter code_A = new SqlParameter("@bimari_c", SqlDbType.NVarChar);
                code_A.Direction = ParameterDirection.Input;
                code_A.Value = textBox7.Text;
                Da.SelectCommand.Parameters.Add(code_A);
                SqlParameter Name_K = new SqlParameter("@daro", SqlDbType.NVarChar);
                Name_K.Direction = ParameterDirection.Input;
                Name_K.Value = textBox2.Text;
                Da.SelectCommand.Parameters.Add(Name_K);
                SqlParameter Name_Kh = new SqlParameter("@tozihat", SqlDbType.NVarChar);
                Name_Kh.Direction = ParameterDirection.Input;
                Name_Kh.Value = textBox3.Text;
                Da.SelectCommand.Parameters.Add(Name_Kh);

                Da.SelectCommand.CommandType = CommandType.StoredProcedure;
                Da.SelectCommand.Connection = dd.connection;
                DataSet ds = new DataSet();
                Da.Fill(ds, "Insert_bimari_cheshmi");
                MessageBox.Show("پایگاه داده با موفقیت بروزرسانی شد.");
            }
            if (radioButton2.Checked == true)
            {

                SqlDataAdapter Da = new SqlDataAdapter();
                Da.SelectCommand = new SqlCommand();
                Da.SelectCommand.CommandText = "Insert_bimari_p";
                SqlParameter code_K = new SqlParameter("@alaem_p", SqlDbType.NVarChar);
                code_K.Direction = ParameterDirection.Input;
                code_K.Value = textBox1.Text;
                Da.SelectCommand.Parameters.Add(code_K);
                SqlParameter code_A = new SqlParameter("@bimari_p", SqlDbType.NVarChar);
                code_A.Direction = ParameterDirection.Input;
                code_A.Value = textBox7.Text;
                Da.SelectCommand.Parameters.Add(code_A);
                SqlParameter Name_K = new SqlParameter("@daro", SqlDbType.NVarChar);
                Name_K.Direction = ParameterDirection.Input;
                Name_K.Value = textBox2.Text;
                Da.SelectCommand.Parameters.Add(Name_K);
                SqlParameter Name_Kh = new SqlParameter("@tozihat", SqlDbType.NVarChar);
                Name_Kh.Direction = ParameterDirection.Input;
                Name_Kh.Value = textBox3.Text;
                Da.SelectCommand.Parameters.Add(Name_Kh);

                Da.SelectCommand.CommandType = CommandType.StoredProcedure;
                Da.SelectCommand.Connection = dd.connection;
                DataSet ds = new DataSet();
                Da.Fill(ds, "Insert_bimari_p");
                MessageBox.Show("پایگاه داده با موفقیت بروزرسانی شد.");
            }
            if (radioButton3.Checked == true)
            {
                SqlDataAdapter Da = new SqlDataAdapter();
                Da.SelectCommand = new SqlCommand();
                Da.SelectCommand.CommandText = "Insert_bimari_d";
                SqlParameter code_K = new SqlParameter("@alaeme_d", SqlDbType.NVarChar);
                code_K.Direction = ParameterDirection.Input;
                code_K.Value = textBox1.Text;
                Da.SelectCommand.Parameters.Add(code_K);
                SqlParameter code_A = new SqlParameter("@bimari_d", SqlDbType.NVarChar);
                code_A.Direction = ParameterDirection.Input;
                code_A.Value = textBox7.Text;
                Da.SelectCommand.Parameters.Add(code_A);
                SqlParameter Name_K = new SqlParameter("@daro", SqlDbType.NVarChar);
                Name_K.Direction = ParameterDirection.Input;
                Name_K.Value = textBox2.Text;
                Da.SelectCommand.Parameters.Add(Name_K);
                SqlParameter Name_Kh = new SqlParameter("@tozihat", SqlDbType.NVarChar);
                Name_Kh.Direction = ParameterDirection.Input;
                Name_Kh.Value = textBox3.Text;
                Da.SelectCommand.Parameters.Add(Name_Kh);

                Da.SelectCommand.CommandType = CommandType.StoredProcedure;
                Da.SelectCommand.Connection = dd.connection;
                DataSet ds = new DataSet();
                Da.Fill(ds, "Insert_bimari_d");
                MessageBox.Show("پایگاه داده با موفقیت بروزرسانی شد.");
            }
        }
    }
}
