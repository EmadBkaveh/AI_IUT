﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace Expert_Health1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            DBconnection db = new DBconnection();
            db.connection.Open();
            if (checkBox2.Checked == true)
            {

                SqlCommand command = new SqlCommand();
                command.CommandType = CommandType.Text;
                command.CommandText = "select * from bimari_p  where alaem_p=N'" + comboBox2.Text + "'";
                DataSet ds = db.readFromDB(command, "search_bimari_p");
                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.Columns.Clear();
                DataGridViewCell cell = new DataGridViewTextBoxCell();
                DataGridViewColumn da = new DataGridViewColumn();
                da.DataPropertyName = ds.Tables["search_bimari_p"].Columns[0].ColumnName;
                da.HeaderText = "علائم بیماری";
                da.CellTemplate = cell;
                dataGridView1.Columns.Add(da);
                DataGridViewColumn da1 = new DataGridViewColumn();
                da1.DataPropertyName = ds.Tables["search_bimari_p"].Columns[1].ColumnName;
                da1.HeaderText = "نام بیماری";
                da1.CellTemplate = cell;
                dataGridView1.Columns.Add(da1);

                DataGridViewColumn da2 = new DataGridViewColumn();
                da2.DataPropertyName = ds.Tables["search_bimari_p"].Columns[2].ColumnName;
                da2.HeaderText = "دارو تجویزی ";
                da2.CellTemplate = cell;
                dataGridView1.Columns.Add(da2);

                DataGridViewColumn da3 = new DataGridViewColumn();
                da3.DataPropertyName = ds.Tables["search_bimari_p"].Columns[3].ColumnName;
                da3.HeaderText = "توضیحات";
                da3.CellTemplate = cell;
                dataGridView1.Columns.Add(da3);
                dataGridView1.DataSource = ds.Tables["search_bimari_p"].DefaultView;
                dataGridView1.ColumnHeadersVisible = true;
                dataGridView1.DataSource = ds.Tables["search_bimari_p"].DefaultView;

            }
            if (checkBox1.Checked == true)
            {
                SqlCommand command = new SqlCommand();
                command.CommandType = CommandType.Text;
                command.CommandText = "select * from bimari_cheshmi  where alaem_cheshmi=N'" + comboBox1.Text + "'";
                DataSet ds = db.readFromDB(command, "search_bimari_cha");
                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.Columns.Clear();
                DataGridViewCell cell = new DataGridViewTextBoxCell();
                DataGridViewColumn da = new DataGridViewColumn();
                da.DataPropertyName = ds.Tables["search_bimari_cha"].Columns[0].ColumnName;
                da.HeaderText = "علائم بیماری";
                da.CellTemplate = cell;
                dataGridView1.Columns.Add(da);
                DataGridViewColumn da1 = new DataGridViewColumn();
                da1.DataPropertyName = ds.Tables["search_bimari_cha"].Columns[1].ColumnName;
                da1.HeaderText = "نام بیماری";
                da1.CellTemplate = cell;
                dataGridView1.Columns.Add(da1);

                DataGridViewColumn da2 = new DataGridViewColumn();
                da2.DataPropertyName = ds.Tables["search_bimari_cha"].Columns[2].ColumnName;
                da2.HeaderText = "دارو تجویزی ";
                da2.CellTemplate = cell;
                dataGridView1.Columns.Add(da2);

                DataGridViewColumn da3 = new DataGridViewColumn();
                da3.DataPropertyName = ds.Tables["search_bimari_cha"].Columns[3].ColumnName;
                da3.HeaderText = "توضیحات";
                da3.CellTemplate = cell;
                dataGridView1.Columns.Add(da3);
                dataGridView1.DataSource = ds.Tables["search_bimari_cha"].DefaultView;
                dataGridView1.ColumnHeadersVisible = true;

            }


            if (checkBox3.Checked == true)
            {
                SqlCommand command = new SqlCommand();
                command.CommandType = CommandType.Text;
                command.CommandText = "select * from bimari_d  where alaeme_d=N'" + comboBox3.Text + "'";
                DataSet ds = db.readFromDB(command, "search_bimari_d");
                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.Columns.Clear();
                DataGridViewCell cell = new DataGridViewTextBoxCell();
                DataGridViewColumn da = new DataGridViewColumn();
                da.DataPropertyName = ds.Tables["search_bimari_d"].Columns[0].ColumnName;
                da.HeaderText = "علائم بیماری";
                da.CellTemplate = cell;
                dataGridView1.Columns.Add(da);
                DataGridViewColumn da1 = new DataGridViewColumn();
                da1.DataPropertyName = ds.Tables["search_bimari_d"].Columns[1].ColumnName;
                da1.HeaderText = "نام بیماری";
                da1.CellTemplate = cell;
                dataGridView1.Columns.Add(da1);

                DataGridViewColumn da2 = new DataGridViewColumn();
                da2.DataPropertyName = ds.Tables["search_bimari_d"].Columns[2].ColumnName;
                da2.HeaderText = "دارو تجویزی ";
                da2.CellTemplate = cell;
                dataGridView1.Columns.Add(da2);

                DataGridViewColumn da3 = new DataGridViewColumn();
                da3.DataPropertyName = ds.Tables["search_bimari_d"].Columns[3].ColumnName;
                da3.HeaderText = "توضیحات";
                da3.CellTemplate = cell;
                dataGridView1.Columns.Add(da3);
                dataGridView1.DataSource = ds.Tables["search_bimari_d"].DefaultView;
                dataGridView1.ColumnHeadersVisible = true;
                dataGridView1.DataSource = ds.Tables["search_bimari_d"].DefaultView;


            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            
            
            DBconnection dd = new DBconnection();
            dd.connection.Open();
            string query = "select * from bimari_p";
            SqlCommand cmd = new SqlCommand(query, dd.connection);
            cmd.CommandType = CommandType.Text;
            DataSet d1 = new DataSet();

            SqlDataReader dr = cmd.ExecuteReader();
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = new SqlCommand(query, dd.connection);

            DataSet ds = new DataSet();



            while (dr.Read())//while true
            {
                string q = dr[0].ToString();
                //     string q1 = dr[2].ToString();
                // string q2 = dr[3].ToString();
                //  x.Items.Add(query);//loading values into dropdown
                // comboBox1.Items.Add(q);
                comboBox2.Items.Add(q);
                //comboBox3.Items.Add(q2);
            }
            dr.Close();//closing the datareader

            //==================================

            string query2 = "select * from bimari_cheshmi";
            SqlCommand cmd1 = new SqlCommand(query2, dd.connection);
            cmd1.CommandType = CommandType.Text;

            SqlDataReader drr = cmd1.ExecuteReader();


            while (drr.Read())//while true
            {
                string q2 = drr[0].ToString();
                //     string q1 = dr[2].ToString();
                // string q2 = dr[3].ToString();
                //  x.Items.Add(query);//loading values into dropdown
                // comboBox1.Items.Add(q);
                comboBox1.Items.Add(q2);
                //comboBox3.Items.Add(q2);
            }
            drr.Close();//closing the datareader

            //======================================
            string query1 = "select * from bimari_d";
            SqlCommand cmdd = new SqlCommand(query1, dd.connection);
            cmdd.CommandType = CommandType.Text;

            SqlDataReader dr1 = cmdd.ExecuteReader();


            while (dr1.Read())//while true
            {
                string q1 = dr1[0].ToString();
                //     string q1 = dr[2].ToString();
                // string q2 = dr[3].ToString();
                //  x.Items.Add(query);//loading values into dropdown
                // comboBox1.Items.Add(q);
                comboBox3.Items.Add(q1);
                //comboBox3.Items.Add(q2);
            }
            dr1.Close();
            dd.connection.Close();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        /* private void button2_Click(object sender, EventArgs e)
         {
             DBconnection dd = new DBconnection();
            /* dd.connection.Open();
             if (radioButton1.Checked == true)
             {

                 SqlDataAdapter Da = new SqlDataAdapter();
                 Da.SelectCommand = new SqlCommand();
                 Da.SelectCommand.CommandText = "Insert_bimari_cheshmi";
                 SqlParameter code_K = new SqlParameter("@alaem_cheshmi", SqlDbType.NVarChar);
                 code_K.Direction = ParameterDirection.Input;
                 code_K.Value = textBox1.Text;
                 Da.SelectCommand.Parameters.Add(code_K);
                 SqlParameter code_A = new SqlParameter("@bimari_c", SqlDbType.NVarChar);
                 code_A.Direction = ParameterDirection.Input;
                 code_A.Value = textBox7.Text;
                 Da.SelectCommand.Parameters.Add(code_A);
                 SqlParameter Name_K = new SqlParameter("@daro", SqlDbType.NVarChar);
                 Name_K.Direction = ParameterDirection.Input;
                 Name_K.Value = textBox2.Text;
                 Da.SelectCommand.Parameters.Add(Name_K);
                 SqlParameter Name_Kh = new SqlParameter("@tozihat", SqlDbType.NVarChar);
                 Name_Kh.Direction = ParameterDirection.Input;
                 Name_Kh.Value = textBox3.Text;
                 Da.SelectCommand.Parameters.Add(Name_Kh);

                 Da.SelectCommand.CommandType = CommandType.StoredProcedure;
                 Da.SelectCommand.Connection = dd.connection;
                 DataSet ds = new DataSet();
                 Da.Fill(ds, "Insert_bimari_cheshmi");
                 MessageBox.Show("پایگاه داده با موفقیت بروزرسانی شد.");
             }
             if (radioButton2.Checked == true)
             {

                 SqlDataAdapter Da = new SqlDataAdapter();
                 Da.SelectCommand = new SqlCommand();
                 Da.SelectCommand.CommandText = "Insert_bimari_p";
                 SqlParameter code_K = new SqlParameter("@alaem_p", SqlDbType.NVarChar);
                 code_K.Direction = ParameterDirection.Input;
                 code_K.Value = textBox1.Text;
                 Da.SelectCommand.Parameters.Add(code_K);
                 SqlParameter code_A = new SqlParameter("@bimari_p", SqlDbType.NVarChar);
                 code_A.Direction = ParameterDirection.Input;
                 code_A.Value = textBox7.Text;
                 Da.SelectCommand.Parameters.Add(code_A);
                 SqlParameter Name_K = new SqlParameter("@daro", SqlDbType.NVarChar);
                 Name_K.Direction = ParameterDirection.Input;
                 Name_K.Value = textBox2.Text;
                 Da.SelectCommand.Parameters.Add(Name_K);
                 SqlParameter Name_Kh = new SqlParameter("@tozihat", SqlDbType.NVarChar);
                 Name_Kh.Direction = ParameterDirection.Input;
                 Name_Kh.Value = textBox3.Text;
                 Da.SelectCommand.Parameters.Add(Name_Kh);

                 Da.SelectCommand.CommandType = CommandType.StoredProcedure;
                 Da.SelectCommand.Connection = dd.connection;
                 DataSet ds = new DataSet();
                 Da.Fill(ds, "Insert_bimari_p");
                 MessageBox.Show("پایگاه داده با موفقیت بروزرسانی شد.");
             }
             if (radioButton3.Checked == true)
             {
                 SqlDataAdapter Da = new SqlDataAdapter();
                 Da.SelectCommand = new SqlCommand();
                 Da.SelectCommand.CommandText = "Insert_bimari_d";
                 SqlParameter code_K = new SqlParameter("@alaeme_d", SqlDbType.NVarChar);
                 code_K.Direction = ParameterDirection.Input;
                 code_K.Value = textBox1.Text;
                 Da.SelectCommand.Parameters.Add(code_K);
                 SqlParameter code_A = new SqlParameter("@bimari_d", SqlDbType.NVarChar);
                 code_A.Direction = ParameterDirection.Input;
                 code_A.Value = textBox7.Text;
                 Da.SelectCommand.Parameters.Add(code_A);
                 SqlParameter Name_K = new SqlParameter("@daro", SqlDbType.NVarChar);
                 Name_K.Direction = ParameterDirection.Input;
                 Name_K.Value = textBox2.Text;
                 Da.SelectCommand.Parameters.Add(Name_K);
                 SqlParameter Name_Kh = new SqlParameter("@tozihat", SqlDbType.NVarChar);
                 Name_Kh.Direction = ParameterDirection.Input;
                 Name_Kh.Value = textBox3.Text;
                 Da.SelectCommand.Parameters.Add(Name_Kh);

                 Da.SelectCommand.CommandType = CommandType.StoredProcedure;
                 Da.SelectCommand.Connection = dd.connection;
                 DataSet ds = new DataSet();
                 Da.Fill(ds, "Insert_bimari_d");
                 MessageBox.Show("پایگاه داده با موفقیت بروزرسانی شد.");
             }*/
        //}
    }
}
